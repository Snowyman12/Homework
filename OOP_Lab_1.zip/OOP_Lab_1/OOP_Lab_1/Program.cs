﻿using System;

class Planet
{
    // Поля класу
    public string Name { get; set; }
    public double Mass { get; set; }       // в кг
    public double Diameter { get; set; }   // в км
    public int Satellites { get; set; }    // кількість супутників

    // Конструктор
    public Planet(string name, double mass, double diameter, int satellites)
    {
        Name = name;
        Mass = mass;
        Diameter = diameter;
        Satellites = satellites;
    }

    // Метод для виводу інформації
    public void PrintInfo()
    {
        Console.WriteLine($"Планета: {Name}");
        Console.WriteLine($"  Маса: {Mass:E} кг");
        Console.WriteLine($"  Діаметр: {Diameter} км");
        Console.WriteLine($"  Кількість супутників: {Satellites}");
        Console.WriteLine();
    }
}

class Program
{
    static void Main()
    {
        // Створення двох екземплярів класу
        Planet earth = new Planet("Земля", 5.972e24, 12742, 1);
        Planet mars = new Planet("Марс", 6.417e23, 6779, 2);

        // Вивід інформації
        earth.PrintInfo();
        mars.PrintInfo();

        Console.ReadLine();
    }
}
