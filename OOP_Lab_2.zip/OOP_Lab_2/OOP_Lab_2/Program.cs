﻿using System;

class Planet
{
    public string Name { get; set; }

    // Закриті поля
    private double mass;       // маса в кг
    private double diameter;   // діаметр в км

    public int Satellites { get; set; }

    // Конструктор
    public Planet(string name, double mass, double diameter, int satellites)
    {
        Name = name;
        this.mass = mass;
        this.diameter = diameter;
        Satellites = satellites;
    }

    // Методи для роботи з масою
    public double GetMass()
    {
        return mass;
    }

    public void SetMass(double mass)
    {
        if (mass > 0)
            this.mass = mass;
        else
            Console.WriteLine("Маса повинна бути додатною!");
    }

    // Методи для роботи з діаметром
    public double GetDiameter()
    {
        return diameter;
    }

    public void SetDiameter(double diameter)
    {
        if (diameter > 0)
            this.diameter = diameter;
        else
            Console.WriteLine("Діаметр повинен бути додатним!");
    }

    // Перевизначення ToString()
    public override string ToString()
    {
        return $"Планета: {Name}\n" +
               $"  Маса: {mass:E} кг\n" +
               $"  Діаметр: {diameter} км\n" +
               $"  Кількість супутників: {Satellites}";
    }
}

class Program
{
    static void Main()
    {
        // Створення об’єктів
        Planet earth = new Planet("Земля", 5.972e24, 12742, 1);
        Planet mars = new Planet("Марс", 6.417e23, 6779, 2);

        // Виведення
        Console.WriteLine(earth);
        Console.WriteLine();
        Console.WriteLine(mars);

        // Приклад зміни приватних полів через set-методи
        mars.SetMass(6.419e23);
        mars.SetDiameter(6780);

        Console.WriteLine("\nПісля змін:");
        Console.WriteLine(mars);
    }
}
